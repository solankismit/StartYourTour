class CheckboxModel {
  var id;
  var price;
  var agency;
  var date;
  var index;


  CheckboxModel({required this.id,required this.price,required this.agency,required this.date,required this.index});
}